package com.david.calendar.calendarapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalendarapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalendarapiApplication.class, args);
	}

}
